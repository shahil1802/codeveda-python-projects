# Times of India News Scraper

This project scrapes top news headlines from the Times of India homepage using Python.

## Features
- Extracts headlines and their URLs
- Saves data in CSV format

## Requirements
```bash
pip install requests beautifulsoup4
```

## How to Run
```bash
python toi_scraper.py
```

## Output
- A CSV file `toi_headlines.csv` with headline and link

## Author
Python Developer Intern — Codveda Technology
