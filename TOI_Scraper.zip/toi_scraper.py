import requests
from bs4 import BeautifulSoup
import csv

# Step 1: Fetch the Times of India homepage
url = "https://timesofindia.indiatimes.com"
response = requests.get(url)
soup = BeautifulSoup(response.content, "html.parser")

# Step 2: Extract top news headlines
headlines = []
for item in soup.find_all('span', class_='w_tle'):
    title = item.get_text(strip=True)
    link_tag = item.find_parent('a')
    link = url + link_tag['href'] if link_tag and 'href' in link_tag.attrs else ''
    headlines.append([title, link])

# Step 3: Save data to CSV
with open('toi_headlines.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['Headline', 'Link'])
    writer.writerows(headlines)

print("✅ Headlines saved to 'toi_headlines.csv'")
