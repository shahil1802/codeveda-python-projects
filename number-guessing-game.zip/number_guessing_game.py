import random

number = random.randint(1, 100)
attempts = 0
max_attempts = 10

while attempts < max_attempts:
    guess = int(input("Guess a number between 1 and 100: "))
    attempts += 1
    if guess == number:
        print("Congratulations! You guessed the number.")
        break
    elif guess < number:
        print("Too low")
    else:
        print("Too high")

if attempts == max_attempts and guess != number:
    print("Sorry, you've used all attempts. The number was", number)
