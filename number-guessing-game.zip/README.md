# Number Guessing Game - Codveda Internship

This Python script is a number guessing game where the user tries to guess a randomly generated number between 1 and 100.

## Features

- Random number generation
- Maximum of 10 attempts
- Feedback on each guess: Too high / Too low
- Reveals correct number if not guessed

## How to Run

```bash
python number_guessing_game.py
```

## Author

Internship project for **Codveda Technology**
