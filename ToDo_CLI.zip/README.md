# 📝 Command-Line To-Do List App

A simple Python-based CLI application to manage your to-dos using JSON storage.

## ✅ Features
- Add tasks
- List all tasks
- Delete tasks by number
- Mark tasks as completed
- Error handling for invalid inputs

## 💻 How to Use

```bash
python todo_cli.py
```

### Commands
- `add <task description>`: Add a new task
- `list`: List all tasks
- `delete <task number>`: Delete a task
- `done <task number>`: Mark a task as completed
- `help`: Show help
- `exit`: Quit the app

## 📂 Files
- `todo_cli.py`: Source code
- `todo_list.json`: Stores tasks

## 📦 Sample Usage
```bash
> add Read Bhagavad Gita
> list
> done 1
> delete 1
```
