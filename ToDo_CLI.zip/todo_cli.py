import json
import os

FILENAME = "todo_list.json"

def load_tasks():
    if not os.path.exists(FILENAME):
        return []
    with open(FILENAME, "r") as f:
        return json.load(f)

def save_tasks(tasks):
    with open(FILENAME, "w") as f:
        json.dump(tasks, f, indent=4)

def add_task(description):
    tasks = load_tasks()
    tasks.append({"task": description, "completed": False})
    save_tasks(tasks)
    print("✅ Task added.")

def list_tasks():
    tasks = load_tasks()
    if not tasks:
        print("📭 No tasks found.")
        return
    for idx, task in enumerate(tasks, start=1):
        status = "✅" if task["completed"] else "❌"
        print(f"{idx}. {task['task']} [{status}]")

def delete_task(index):
    tasks = load_tasks()
    try:
        task = tasks.pop(index - 1)
        save_tasks(tasks)
        print(f"🗑️ Task '{task['task']}' deleted.")
    except IndexError:
        print("⚠️ Error: Task number does not exist.")

def mark_done(index):
    tasks = load_tasks()
    try:
        tasks[index - 1]["completed"] = True
        save_tasks(tasks)
        print(f"🎉 Task '{tasks[index - 1]['task']}' marked as completed.")
    except IndexError:
        print("⚠️ Error: Task number does not exist.")

def show_help():
    print("""
📌 Commands:
  add <task description>    - Add a new task
  list                      - List all tasks
  delete <task number>      - Delete a task by number
  done <task number>        - Mark a task as done
  help                      - Show this help message
  exit                      - Exit the app
""")

def main():
    print("📝 Welcome to the Command-Line To-Do List App!")
    show_help()
    while True:
        command = input("\n> ").strip().split()
        if not command:
            continue
        action = command[0].lower()
        if action == "add":
            description = " ".join(command[1:])
            if description:
                add_task(description)
            else:
                print("⚠️ Please provide a task description.")
        elif action == "list":
            list_tasks()
        elif action == "delete":
            if len(command) > 1 and command[1].isdigit():
                delete_task(int(command[1]))
            else:
                print("⚠️ Please provide a valid task number.")
        elif action == "done":
            if len(command) > 1 and command[1].isdigit():
                mark_done(int(command[1]))
            else:
                print("⚠️ Please provide a valid task number.")
        elif action == "help":
            show_help()
        elif action == "exit":
            print("👋 Goodbye!")
            break
        else:
            print("❓ Unknown command. Type 'help' to see available commands.")

if __name__ == "__main__":
    main()
