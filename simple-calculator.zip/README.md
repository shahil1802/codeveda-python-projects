# Simple Calculator - Codveda Internship

This Python script is a basic calculator that performs:

- Addition
- Subtraction
- Multiplication
- Division (with zero-division handling)

## How to Run

```bash
python simple_calculator.py
```

## Input

- Two numbers
- Operation choice

## Output

- Result of the operation

## Author

Internship project for **Codveda Technology**
