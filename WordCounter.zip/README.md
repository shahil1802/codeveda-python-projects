# Word Counter with GUI and Unique Word Analysis

This Python project reads a text file, counts the total number of words and unique words in it, and handles file errors gracefully.

## Features
- GUI-based file selection using `tkinter`
- Total and unique word counting
- Graceful error handling (e.g., file not found)

## How to Run
1. Make sure Python is installed.
2. Run the script:
   ```bash
   python word_counter_gui.py
   ```
3. Select any `.txt` file via the file picker dialog.
4. The result will be shown in the terminal.

## Sample Output
```
File: sample.txt
Total words: 25
Unique words: 18
```

## Files
- `word_counter_gui.py` - The main source code
- `sample.txt` - Sample file to test the program
