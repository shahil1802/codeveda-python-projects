import tkinter as tk
from tkinter import filedialog
from collections import Counter

def count_words_in_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            content = file.read()
            words = content.split()
            total_words = len(words)
            unique_words = len(set(words))
            print(f"\nFile: {filepath}")
            print(f"Total words: {total_words}")
            print(f"Unique words: {unique_words}")
    except FileNotFoundError:
        print(f"Error: The file '{filepath}' was not found.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def open_file_picker():
    filepath = filedialog.askopenfilename(
        title="Select a Text File",
        filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
    )
    if filepath:
        count_words_in_file(filepath)

root = tk.Tk()
root.withdraw()
open_file_picker()
